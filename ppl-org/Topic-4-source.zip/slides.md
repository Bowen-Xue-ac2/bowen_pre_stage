---
theme: seriph
title: Leadership and Organisational Effectiveness
layout: default
defaults:
  layout: default
routerMode: hash
canvasWidth: 1200
aspectRatio: 16/9
colorSchema: light
transition: none
fonts:
  sans: Liberation Sans
  serif: Liberation Serif
  provider: none
  local: [Liberation Sans, Liberation Serif]
drawings:
  enabled: false
download: false
favicon: /favicon.svg
---
<div class="frame opening" ><h1 class="" >Leadership &amp; organisational effectiveness</h1><div class="venn" ><div class="circle c0" ></div><div class="circle c1" ></div><div class="circle c2" ></div><span class="vl l0" >Fair power</span><span class="vl l1" >Effective empowerment</span><span class="vl l2" >Team learning</span></div><div class="opening-slot" v-click><p class="slot" >[empty]</p></div></div>

<!--
开场 - 引入辩题与组织有效性 - 将绩效、员工承担的代价和领导责任一起评价 - 预告公平用权、有效授权与团队学习三条论证线。

[empty]
-->


---

<div class="frame compare" ><h1 class="" >Leadership styles</h1><div class="split" ><div class="unit" ><div class="actors" ><img class="actor" src="/figures/person-2-0.svg" alt=""><img class="actor" src="/figures/person-2-1.svg" alt=""></div><h2 class="" >Servant leadership</h2><p class="term" >Follower development</p><p class="term" >Employee needs</p><p class="term" >Shared input</p><p class="citation" >(Eva et al., 2019)</p></div><div class="unit" v-click><div class="actors" ><img class="actor" src="/figures/person-2-2.svg" alt=""><img class="actor" src="/figures/person-2-3.svg" alt=""><img class="actor" src="/figures/person-2-4.svg" alt=""></div><h2 class="" >Traditional leadership</h2><p class="term" >Hierarchical authority</p><p class="term" >Centralised decisions</p><p class="term" >Supervisory control</p></div></div></div>

<!--
概念 - 服务型领导关注员工成长与需要 - 传统领导采用本组操作性定义 - 两类实践可以并存 - 共同承担组织责任。

权威与参与 - 比较同一资源分配情境 - 左侧听取员工意见后决定 - 右侧领导直接决定 - 员工提供信息，领导解释并承担最终责任。
-->


---

<div class="frame case" ><p class="kicker" >Management practices · FY2016</p><h1 class="" >Whole Foods</h1><div class="split" ><div class="unit" ><img class="icon" src="/figures/file-check-2.svg" alt=""><h2 class="" >Pay transparency</h2><p class="big" >Employee access</p><p class="citation" >(Whole Foods Market, Inc., 2016)</p></div><div class="unit" v-click><h2 class="" >Justice &amp; trust</h2><p class="term" >Perceived fairness</p><p class="term" >Employee feedback</p><p class="citation" >(Lee et al., 2020)</p><p class="slot" >[empty]</p></div></div></div>

<!--
锁定收购前2016年 - 薪酬信息向员工开放 - 对应公平、透明度和权力约束 - 制度披露与员工体验分层评价。

表达机会和一致标准对应程序公平 - 尊重对应人际公平 - 充分解释对应信息公平。

[empty]
-->


---

<div class="frame case" ><h1 class="" >Whole Foods: ethical evaluation</h1><div class="split" ><div class="unit" ><img class="icon" src="/figures/heart-pulse.svg" alt=""><h2 class="" >Policy design</h2><p class="big" >Health incentives</p><p class="term" >Biometric eligibility</p><p class="citation" >(Whole Foods Market, Inc., 2016)</p></div><div class="unit" v-click><h2 class="" >Ethical implications</h2><p class="term" >Autonomy · Distributive fairness</p><p class="term" >Unequal starting conditions</p><p class="term" >Appeal channels</p><p class="slot" >[empty]</p></div></div></div>

<!--
伦理分析 - 额外员工折扣与生物指标相关 - 讨论健康支持、员工自主和不同健康起点 - 制度事实源自年报 - 公平评价为本组分析 - 员工体验与分配效果需要进一步资料。

[empty]
-->


---

<div class="frame case" ><h1 class="" >Amazon: decision-making</h1><div class="split" ><div class="unit" ><h2 class="" >Disagree &amp; commit</h2><div class="actors" ><img class="actor" src="/figures/person-2-0.svg" alt=""><img class="actor" src="/figures/person-2-1.svg" alt=""></div><p class="term" >Dissent → Shared execution</p><p class="citation" >(Amazon Staff, 2017)</p><p class="slot" >[empty]</p></div><div class="unit" v-click><h2 class="" >Reversible decisions</h2><p class="big" >Decentralised authority</p><p class="citation" >(Amazon Staff, 2017)</p></div></div></div>

<!--
Amazon实践 - 2016年度股东信发表于2017年 - 可逆决策适合更快授权 - 意见分歧与共同执行相衔接 - 体现集中决策与分散授权的组合 - 股东信属于管理实践自述。

[empty]
-->


---

<div class="frame case" ><h1 class="" >Performance &amp; worker protection</h1><div class="split" ><div class="unit" ><img class="icon" src="/figures/clipboard-check.svg" alt=""><h2 class="" >Robbinsville</h2><p class="term" >Injury &amp; illness recordkeeping</p><p class="term" >OSHA citation</p><p class="citation" >(U.S. Department of Labor, 2016)</p></div><div class="unit" v-click><h2 class="" >Evidence gap</h2><p class="term" >Meaningful voice</p><p class="term" >Employee experience</p><p class="term" >Responsive decisions</p><p class="slot" >[empty]</p></div></div></div>

<!--
Robbinsville单一履约中心的2016监管材料分别涉及伤病记录citation和人体工学hazard-alert letter - 监管材料对应特定场所与事件。

[empty]
-->


---

<div class="frame learning" ><h1 class="" >Voice &amp; team learning</h1><div class="learning-top" ><div class="actors" ><img class="actor" src="/figures/person-10-0.svg" alt=""><img class="actor" src="/figures/person-10-1.svg" alt=""><img class="actor" src="/figures/person-10-2.svg" alt=""><img class="actor" src="/figures/person-10-3.svg" alt=""></div><div class="learning-side" ><h2 class="" >Psychological safety</h2><p class="citation" >(Edmondson, 1999)</p></div></div><div class="pathway" ><div class="phase-cell" ><p class="phase" >Speak up</p></div><div class="phase-cell" v-click><p class="phase" >Share information</p></div><div class="phase-cell" v-click><p class="phase" >Learn &amp; correct</p></div></div><p class="slot" >[empty]</p></div>

<!--
团队学习 - 以员工提出问题为起点 - 心理安全支持承担人际风险、承认错误与共享信息 - 连接纠错与学习 - Edmondson研究覆盖51个工作团队，横截面证据支持统计关联 - 建设性异议配合明确绩效标准。

[empty]
-->


---

<div class="frame compare" ><h1 class="" >Execution &amp; development over time</h1><div class="split" ><div class="unit" ><div class="actors" ><img class="actor" src="/figures/person-11-0.svg" alt=""><img class="actor" src="/figures/person-11-1.svg" alt=""></div><h2 class="" >Directive</h2><p class="term" >Early coordination</p></div><div class="unit" v-click><div class="actors" ><img class="actor" src="/figures/person-11-2.svg" alt=""><img class="actor" src="/figures/person-11-3.svg" alt=""></div><h2 class="" >Empowering</h2><p class="term" >Subsequent learning &amp; improvement</p></div></div><div class="local-cite" ><p class="citation" >60 teams · (Lorinkova et al., 2013)</p></div></div>

<!--
时间维度 - Lorinkova等研究60个团队 - 指令式领导在早期协调上具有优势 - 赋权式团队后续改善更快 - 两条路径表达阶段性机制 - 该研究直接比较directive与empowering - 将其用于本题的补充机制讨论。

[empty]
-->


---

<div class="frame conclusion" ><h1 class="" >Qualified agreement</h1><div class="claims" ><div class="claim" ><h2 class="" >Fair power</h2></div><div class="claim" ><h2 class="" >Effective empowerment</h2></div><div class="claim" ><h2 class="" >Team learning</h2></div></div><div class="split" ><div class="unit" ><h2 class="" >Learning &amp; collaboration</h2><p class="term" >Participation · Empowerment</p></div><div class="unit" v-click><h2 class="" >Urgent decisions</h2><p class="term" >Ownership · Escalation · Review</p></div></div><p class="citation" >(Lee et al., 2020; Lorinkova et al., 2013)</p><p class="slot" >[empty]</p></div>

<!--
结论 - 有条件赞同 - 公平决策建立信任 - 员工发展结合目标和能力 - 团队发声支持学习纠错 - 服务型领导可以支持持续有效性，实施条件包括清晰目标、充分资源与问责 - 具体优势随任务与时间尺度变化。

[empty]
-->


---

<div class="frame refs" ><h1 class="" >References</h1><div class="ref-cols" ><div class="" ><p><a href="https://www.aboutamazon.com/news/company-news/2016-letter-to-shareholders">Amazon Staff. (2017, April 17). <i>2016 letter to shareholders</i>. About Amazon.</a></p><p><a href="https://doi.org/10.2307/2666999">Edmondson, A. (1999). Psychological safety and learning behavior in work teams. <i>Administrative Science Quarterly</i>, 44(2), 350–383.</a></p><p><a href="https://doi.org/10.1016/j.leaqua.2018.07.004">Eva, N., Robin, M., Sendjaya, S., van Dierendonck, D., &amp; Liden, R. C. (2019). Servant leadership: A systematic review and call for future research. <i>The Leadership Quarterly</i>, 30(1), 111–132.</a></p><p><a href="https://doi.org/10.1111/joop.12265">Lee, A., Lyubovnikova, J., Tian, A. W., &amp; Knight, C. (2020). Servant leadership: A meta-analytic examination of incremental contribution, moderation, and mediation. <i>Journal of Occupational and Organizational Psychology</i>, 93(1), 1–44.</a></p></div><div class="" ><p><a href="https://doi.org/10.5465/amj.2011.0132">Lorinkova, N. M., Pearsall, M. J., &amp; Sims, H. P., Jr. (2013). Examining the differential longitudinal performance of directive versus empowering leadership in teams. <i>Academy of Management Journal</i>, 56(2), 573–596.</a></p><p><a href="https://www.dol.gov/newsroom/releases/osha/osha20160112">U.S. Department of Labor. (2016, January 12). <i>Amazon fulfillment center receives $7K fine, hazard alert letters after OSHA investigates workplace safety complaint</i>.</a></p><p><a href="https://www.sec.gov/Archives/edgar/data/865436/000086543616000366/wfm10k2016.htm">Whole Foods Market, Inc. (2016). <i>Annual report on Form 10-K for the fiscal year ended September 25, 2016</i>. U.S. Securities and Exchange Commission.</a></p><p class="slot" >[empty]</p></div></div></div>

<!--
[empty]
-->
