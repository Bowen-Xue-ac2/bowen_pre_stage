<script setup>
const routes = Array.from({length: 17}, (_, i) => {
  const y = (i - 8) * 7
  const bend = 110 + Math.abs(i - 8) * 9
  const drift = (i < 8 ? -1 : 1) * (28 + Math.abs(i - 8) * 4)
  const end = 245 + ((i * 43) % 139)
  return { path: `M 72 ${y} H ${bend} l ${Math.abs(drift)} ${drift} H ${end}`, x:end, y:y+drift, delay:i*55 }
})
</script>
<template>
<svg class="pcb-art" viewBox="0 0 980 552" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
  <defs>
    <radialGradient id="pcb-field"><stop stop-color="#00140c"/><stop offset="1" stop-color="#000202"/></radialGradient>
    <pattern id="pcb-vias" width="23" height="23" patternUnits="userSpaceOnUse"><circle cx="4" cy="4" r="1.2" fill="#60a28a" opacity=".42"/></pattern>
    <linearGradient id="pcb-case" x2="1" y2="1"><stop stop-color="#314c40"/><stop offset=".55" stop-color="#182f28"/><stop offset="1" stop-color="#446a52"/></linearGradient>
    <filter id="pcb-light" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.8"/></filter>
  </defs>
  <rect width="980" height="552" fill="url(#pcb-field)"/><rect width="980" height="552" fill="url(#pcb-vias)"/>
  <g transform="translate(550 245) rotate(-21)">
    <g v-for="angle in [0,90,180,270]" :key="angle" :transform="`rotate(${angle})`">
      <g v-for="(r,i) in routes" :key="i">
        <path :d="r.path" fill="none" stroke="#416b51" stroke-width="2.1" opacity=".62"/>
        <path class="current" :d="r.path" pathLength="1" fill="none" stroke="#78bf95" stroke-width="2" :style="{'--lag':(r.delay+angle*1.2)+'ms'}"/>
        <circle :cx="r.x" :cy="r.y" r="3.3" fill="#14392b" stroke="#b4c593" stroke-width="1.5"/>
        <rect x="68" :y="(i-8)*7-1.6" width="16" height="3.2" fill="#c6c899"/>
      </g>
      <g v-for="i in 7" :key="'part'+i" :transform="`translate(${168+i*18} ${92+i%3*9})`">
        <rect x="-7" y="-3" width="14" height="6" rx="1" fill="#a0a38c"/><rect x="-4.2" y="-3.2" width="8.4" height="6.4" fill="#243b30"/>
      </g>
    </g>
    <rect x="-69" y="-69" width="138" height="138" rx="8" fill="url(#pcb-case)" stroke="#98b49d" stroke-width="2"/>
    <rect x="-55" y="-55" width="110" height="110" rx="4" fill="#112a22" stroke="#537662"/>
    <circle cx="-47" cy="-47" r="3" fill="#a4b29f"/>
    <g stroke="#516e5c" stroke-width="2"><path d="M-32 10h64M-32 17h49M-32 24h30"/></g>
  </g>
</svg>
</template>
