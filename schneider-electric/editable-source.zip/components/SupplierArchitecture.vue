<script setup>
import { onMounted, ref, useId } from 'vue'
import definition from '../diagrams/supplier-emissions.mmd?raw'

const diagram = ref('')
const id = 'supply' + useId().replace(/[^a-z0-9]/gi, '')
onMounted(async () => {
  const { default: mermaid } = await import('mermaid')
  mermaid.initialize({
    startOnLoad: false,
    theme: 'base',
    htmlLabels: false,
    securityLevel: 'strict',
    themeVariables: { fontFamily: 'Arial, sans-serif', fontSize: '16px', lineColor: '#46755c' },
    flowchart: { htmlLabels: false, curve: 'monotoneX', wrappingWidth: 185, rankSpacing: 32, nodeSpacing: 34, padding: 12, diagramPadding: 6 }
  })
  diagram.value = (await mermaid.render(id, definition)).svg
})
</script>

<template>
  <div class="supplier-arch">
    <h1>供应商取得资格后，怎样核验减排？</h1>
    <div class="arch-svg" v-html="diagram" role="img" aria-label="采购团队提供工具后，供应商分别进入资格评定和工厂改造路径。改造项目需实测排放，再核算采购贡献。" />
    <div class="arch-target"><b>2030 集团目标</b><span>Scope 3 较 2021 年减 25%。上游采购是其中一项来源。</span></div>
    <div class="arch-boundary">核算边界：自有运营 Scope 1+2 另以 2017 年为基准；客户避免排放单列。</div>
    <div class="arch-cite">资料：Schneider Electric，2025 可持续发展报告（第 23–25、80 页）、2026 Q3 进展、Impact 2030；核验方案据小组调研。</div>
  </div>
</template>
