<script setup>
import { onMounted, onUnmounted } from 'vue'
import { useNav } from '@slidev/client'
const { next } = useNav()
function advanceOnCanvas(event) {
  if (event.defaultPrevented || event.button !== 0 || !event.target.closest?.('.slidev-layout')) return
  if (!/^#\/(?:\d+)?(?:\?|$)/.test(location.hash) || event.target.closest('a, button, input, textarea, [contenteditable]')) return
  if (window.getSelection()?.toString()) return
  next()
}
onMounted(() => document.addEventListener('click', advanceOnCanvas))
onUnmounted(() => document.removeEventListener('click', advanceOnCanvas))
</script>
<template><span hidden></span></template>
