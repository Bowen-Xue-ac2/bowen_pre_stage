---
theme: default
title: Social Impact Assessment
favicon: ./circuit.svg
routerMode: hash
colorSchema: light
transition: fade
fonts:
  sans: Arial
  provider: none
---

<div class="power-scene"><PcbBoard/><div class="power-pulse" v-click="1"></div><div class="opening-question" v-click="2"><div>Who is Schneider Electric?</div><div>How does it affect your life?</div></div></div>

---

<div class="mission-scene"><h1>Our mission is to be the trusted partner in Sustainability and Efficiency.</h1><div class="company-facts"><div v-click="1"><h3>公司简介</h3><p>[empty]</p></div><div v-click="2"><h3>主要业务</h3><p>[empty]</p></div></div></div>

---

<h1>三项社会影响目标</h1>
<div class="deal " v-click="1"><article><div class="photo-slot">[empty]</div><h2>环境</h2><p>[empty]</p></article><article><div class="photo-slot">[empty]</div><h2>社会</h2><p>[empty]</p></article><article><div class="photo-slot">[empty]</div><h2>经济</h2><p>[empty]</p></article></div>

---

<div class="bridge-page"><h1>告诉观众我们选择社会&amp;环境影响</h1></div>

---

<h1>社会影响</h1>
<div class="fish"><div class="spine"></div><div class="bone b0" v-click="1"><i></i><section><label>投入</label><h3>项目资源与运维</h3><p>以 1 个试点社区为例，为设备和本地维护配置资源。</p><small>小组方案</small></section></div><div class="bone b1" v-click="2"><i></i><section><label>活动</label><h3>接入前建立基线</h3><p>开展 1 次入户基线调查，此后按月记录供电和支出。</p><small>小组方案</small></section></div><div class="bone b2" v-click="3"><i></i><section><label>产出</label><h3>接入可持续电力</h3><p>截至 2026 Q3，全球累计覆盖 6,900 万人，较上半年增加 190 万。</p><small>公司披露</small></section></div><div class="bone b3" v-click="4"><i></i><section><label>成果</label><h3>追踪持续用电</h3><p>2027–28 年回访：家庭看能源支出占比，社区看户均停电时长。</p><small>拟议跟踪</small></section></div><div class="bone b4" v-click="5"><i></i><section><label>影响</label><h3>扩大能源可及性</h3><p>2030 年累计覆盖 1 亿人；长期可负担性仍需回访验证。</p><small>公司目标</small></section></div></div>

---

<div class="hold-page"><h1>社会影响评价</h1><p>［评价内容待补充］</p></div>

---
clicks: 6
---

<SupplierArchitecture :step="$clicks" />

---

<div class="hold-page"><h1>［待定］</h1></div>

---

<h1>Sustainable Development Goals</h1>
<div class="deal goal-deal" v-click="1"><article><img :src="'./media/solar.jpg'" alt="Agrivoltaic panels at Flakkebjerg"><div class="goal-body"><label>Goal 7</label><h2>Affordable and Clean Energy</h2><p>Ensure access to affordable, reliable, sustainable and modern energy for all</p></div></article><article><img :src="'./media/launch.jpg'" alt="Launch of the DSCOVR spacecraft"><div class="goal-body"><label>Goal 9</label><h2>Industry, Innovation and Infrastructure</h2><p>Build resilient infrastructure, promote inclusive and sustainable industrialization and foster innovation</p></div></article><article><img :src="'./media/glacier.jpg'" alt="Aletsch Glacier, Switzerland"><div class="goal-body"><label>Goal 13</label><h2>Climate Action</h2><p>Take urgent action to combat climate change and its impacts</p></div></article></div>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="split"><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div><div class="split"><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div><div class="note" v-click>[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="kpis"><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section></div>

<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="bibliography"><p>[empty] <a href="https://download.se.com/files?p_Doc_Ref=2025_Sustainability_Report&amp;p_enDocType=Institutional+Document">[empty]</a></p><p>[empty]<a href="https://doi.org/10.1086/705417">[empty]</a> <i>[empty]</i>[empty]</p><p>[empty]<a href="https://www.se.com/ww/en/about-us/investor-relations/investment/esg/">[empty]</a></p><p>[empty]<a href="https://www.se.com/ww/en/about-us/sustainability/our-impact/">[empty]</a></p><p>[empty]<a href="https://perspectives.se.com/case-study/maximizing-cement-production-efficiency-for-cnbm">[empty]</a></p><p>[empty]<a href="https://www.se.com/ww/en/about-us/newsroom/news/press-releases/schneider-electric-reports-robust-sustainability-progress-for-its-third-quarter-results-6ad1ab2a5d3dbde2c90c14a3/">[empty]</a></p><p>[empty]<a href="https://www.se.com/za/en/about-us/newsroom/news/press-releases/schneider-electric-to-become-the-official-energy-technology-partner-of-mclaren-racing-6978b17cef0e31a06901130d/">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal13">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal7">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal9">[empty]</a></p><p><a href="./photo-credits.txt" target="_blank">图片来源与许可</a></p></div>
<footer>[empty]<span>[empty]</span></footer>
