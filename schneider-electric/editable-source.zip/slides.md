---
theme: default
title: Schneider Electric | Impact 2030
routerMode: hash
colorSchema: light
transition: fade
fonts:
  sans: Arial
  provider: none
---

<div class="cover">
<header>[empty]<span>[empty]</span></header>
<div class="arc"></div>
<h1>[empty]<br>[empty]<br>[empty]</h1>
<p>[empty]</p>
<footer>[empty]<span>[empty]</span></footer>
</div>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="split"><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div><div class="split" v-click><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="kpis"><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section></div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="lanes"><section><label>[empty]</label><h3>[empty]</h3><p>[empty]</p></section><section><label>[empty]</label><h3>[empty]</h3><p>[empty]</p></section><section><label>[empty]</label><h3>[empty]</h3><p>[empty]</p></section></div><div class="note">[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="kpis"><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><p>[empty]</p></section></div><div class="note" v-click>[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="chain"><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section></div><div class="note">[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="gauge"><div><b>[empty]</b>[empty]</div><div class="track"><i style="width:69%"></i></div><div class="ends"><span>[empty]</span><span>[empty]</span></div></div><div class="note" v-click>[empty]</div><p class="academic">[empty]</p>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="chain"><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section><section><label>[empty]</label><p>[empty]</p></section></div><div class="note">[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="comparison"><div><b>[empty]</b><span>[empty]</span></div><div class="track"><i style="width:83%"></i><em style="left:90%"></em></div></div><div class="comparison"><div><b>[empty]</b><span>[empty]</span></div><div class="track"><i style="width:12%"></i><em style="left:25%"></em></div></div><div class="ends"><span>[empty]</span><span>[empty]</span><span>[empty]</span></div><div class="note" v-click>[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="kpis goals"><section><label>[empty]</label><strong>[empty]</strong><h3>[empty]</h3><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><h3>[empty]</h3><p>[empty]</p></section><section><label>[empty]</label><strong>[empty]</strong><h3>[empty]</h3><p>[empty]</p></section></div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="split"><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div><div class="split"><aside>[empty]</aside><section><h3>[empty]</h3><p>[empty]</p></section></div><div class="note" v-click>[empty]</div>
<footer>[empty]<span>[empty]</span></footer>

---

<header>[empty]<span>[empty]</span></header>

<h1>[empty]</h1>

<div class="bibliography"><p>[empty]<a href="https://doi.org/10.1086/705417">[empty]</a> <i>[empty]</i>[empty]</p><p>[empty]<a href="https://www.se.com/ww/en/about-us/investor-relations/investment/esg/">[empty]</a></p><p>[empty]<a href="https://www.se.com/ww/en/about-us/sustainability/our-impact/">[empty]</a></p><p>[empty]<a href="https://perspectives.se.com/case-study/maximizing-cement-production-efficiency-for-cnbm">[empty]</a></p><p>[empty]<a href="https://www.se.com/ww/en/about-us/newsroom/news/press-releases/schneider-electric-reports-robust-sustainability-progress-for-its-third-quarter-results-6ad1ab2a5d3dbde2c90c14a3/">[empty]</a></p><p>[empty]<a href="https://www.se.com/za/en/about-us/newsroom/news/press-releases/schneider-electric-to-become-the-official-energy-technology-partner-of-mclaren-racing-6978b17cef0e31a06901130d/">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal13">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal7">[empty]</a></p><p>[empty]<a href="https://sdgs.un.org/goals/goal9">[empty]</a></p></div>
<footer>[empty]<span>[empty]</span></footer>
