---
theme: default
title: Schneider Electric | Impact 2030
routerMode: hash
colorSchema: light
transition: fade
fonts:
  sans: Arial
  provider: none
---

<div class="cover">
<header>Schneider Electric <span>Impact 2030</span></header>
<div class="arc"></div>
<h1>What changes when<br>electricity reaches<br>more people?</h1>
<p>Energy access, industrial efficiency and emissions</p>
<footer>Company impact assessment <span>November 2026</span></footer>
</div>

---

<header>Mission<span>Schneider Electric · Impact 2030</span></header>

# Where is Schneider’s impact easiest to verify?

<div class="split"><aside>Schneider’s mission</aside><section><h3>“Our mission is to be the trusted partner in Sustainability and Efficiency.”</h3><p>The promise applies to people buying electricity, factories using it and suppliers producing equipment.</p></section></div><div class="split" v-click><aside>Our assessment</aside><section><h3>The clearest results have a baseline.</h3><p>Factory energy per unit and Schneider’s operating emissions have one. For households, the reach figure leaves open how long service stays affordable.</p></section></div>
<footer>Schneider Electric (2026b), “About Schneider Electric,” para. 2<span>02 / 12</span></footer>

---

<header>Three impact aims<span>Schneider Electric · Impact 2030</span></header>

# Three measures show who benefits and how

<div class="kpis"><section><label>Social · households</label><strong>69m</strong><p>People gained access to sustainable electricity since 2009, through Q3 2026.</p></section><section><label>Economic · one customer</label><strong>3–5%</strong><p>Less energy per unit of cement production in the CNBM case published in 2020.</p></section><section><label>Environmental · operations</label><strong>83%</strong><p>Reduction in Schneider’s Scope 1 and 2 emissions at Q3 2026 versus 2017.</p></section></div>
<footer>Schneider Electric (2020, 2026a). Indicators have different units and populations.<span>03 / 12</span></footer>

---

<header>Stakeholders<span>Schneider Electric · Impact 2030</span></header>

# Who can verify each claim?

<div class="lanes"><section><label>Schneider · internal</label><h3>Programme and procurement teams</h3><p>Choose projects and purchasing standards. They can report deployment and set supplier requirements.</p></section><section><label>Delivery · external</label><h3>Local operators and suppliers</h3><p>Operators record outages and payments. Suppliers measure factory emissions and decide which upgrades to fund.</p></section><section><label>Users · external</label><h3>Households and industrial customers</h3><p>Families can report unaffordable bills. Plant managers can compare energy use per unit of output.</p></section></div><div class="note">A programme can reach more households while existing connections become too expensive to use.</div>
<footer>Stakeholder analysis based on Schneider Electric (2020, 2026a)<span>04 / 12</span></footer>

---

<header>Economic aim<span>Schneider Electric · Impact 2030</span></header>

# CNBM used less energy per unit of cement

<div class="kpis"><section><label>Across customers</label><strong>211m</strong><p>MWh saved or electrified, Jan–Sep 2026. This combined measure gives no separate total for savings.</p></section><section><label>CNBM case</label><strong>3–5%</strong><p>Less energy consumed per production unit after kiln control and energy management upgrades.</p></section><section><label>Investment recovery</label><strong>&lt;2 years</strong><p>Reported time to recover the investment in the CNBM case.</p></section></div><div class="note" v-click>The case gives a customer-level economic result. Its payback period cannot be extrapolated across Schneider’s customers.</div>
<footer>Schneider Electric (2020, 2026a). CNBM results are supplier-reported.<span>05 / 12</span></footer>

---

<header>Theory of Change 01 · Energy access<span>Schneider Electric · Impact 2030</span></header>

# How can a new connection deliver lasting service?

<div class="chain"><section><label>Inputs</label><p>Equip 1 local operator with installation and maintenance funding.</p></section><section><label>Processes</label><p>Register 1 cohort of newly connected households and record its starting tariff.</p></section><section><label>Outputs · year 1</label><p>Count people gaining access. Globally, Schneider reported 1.9m additional people in Q3 2026.</p></section><section><label>Outcomes · months 12–18</label><p>Revisit the same cohort at 12 months. Count households still served and record outages and bills.</p></section><section><label>Impact · 2030</label><p>Official target of 100m people reached since 2009. Lasting affordability requires separate follow-up.</p></section></div><div class="note">The proposed pilot explains how to test the pathway. The published reach figures cover the global programme.</div>
<footer>Pilot design is illustrative. Global figures from Schneider Electric (2026a, n.d.-b).<span>06 / 12</span></footer>

---

<header>Household evidence<span>Schneider Electric · Impact 2030</span></header>

# 31 million more people would bring reported reach to the 2030 target

<div class="gauge"><div><b>69m</b> reported by Q3 2026</div><div class="track"><i style="width:69%"></i></div><div class="ends"><span>0</span><span>100m · official 2030 target</span></div></div><div class="note" v-click>How many still have affordable service a year later? Count households still using electricity, report any lost to follow-up, and compare bills with household spending.</div><p class="academic">In a rural Kenyan grid experiment, newly connected households used little electricity on average. That finding motivates follow-up in Schneider’s programme.</p>
<footer>Schneider Electric (2026a, n.d.-b) and Lee et al. (2020). Gap = 100m − 69m.<span>07 / 12</span></footer>

---

<header>Theory of Change 02 · Supplier emissions<span>Schneider Electric · Impact 2030</span></header>

# How could supplier training reduce emissions?

<div class="chain"><section><label>Inputs</label><p>Digital tools deployed for over 1,200 suppliers in 2026.</p></section><section><label>Processes</label><p>10 bootcamps and more than 250 live coaching sessions.</p></section><section><label>Outputs · 2026</label><p>135 suppliers qualified at Q3, up from 15 at H1.</p></section><section><label>Outcomes · months 12–18</label><p>Proposed test: compare 2 annual emissions inventories for the same qualified suppliers.</p></section><section><label>Impact · 2030</label><p>Target of 1,500 qualified suppliers. Verified supplier cuts can contribute to the group’s 25% Scope 3 reduction goal.</p></section></div><div class="note">Qualification requires emissions measurement and target-setting. Changes in purchased volumes and product use also affect the group total.</div>
<footer>Schneider Electric (2026a, n.d.-a, n.d.-b). Scope 3 target baseline: 2021.<span>08 / 12</span></footer>

---

<header>Emissions evidence<span>Schneider Electric · Impact 2030</span></header>

# Operations and value-chain emissions have different trajectories

<div class="comparison"><div><b>Scope 1 + 2 · Q3 2026 versus 2017</b><span>83% reported · 90% target</span></div><div class="track"><i style="width:83%"></i><em style="left:90%"></em></div></div><div class="comparison"><div><b>Scope 3 · FY2025 versus 2021</b><span>12% reported · 25% target</span></div><div class="track"><i style="width:12%"></i><em style="left:25%"></em></div></div><div class="ends"><span>0% reduction</span><span>Blue bar = reported reduction　│ = 2030 target</span><span>100%</span></div><div class="note" v-click>Scope 3 includes emissions from customers using sold products. The group-wide change cannot be attributed to supplier qualification alone.</div>
<footer>Schneider Electric (2026a, n.d.-a, n.d.-b). Each row uses its own baseline and reporting period.<span>09 / 12</span></footer>

---

<header>Sustainable Development Goals<span>Schneider Electric · Impact 2030</span></header>

# Three SDGs call for three different tests

<div class="kpis goals"><section><label>Household access</label><strong>07</strong><h3>Affordable and Clean Energy</h3><p>69m reached. Target 7.1 also calls for reliable, affordable service. Follow the same households over time.</p></section><section><label>Industrial efficiency</label><strong>09</strong><h3>Industry, Innovation and Infrastructure</h3><p>Target 9.4 concerns resource efficiency. CNBM’s energy use per unit gives a direct test at one producer.</p></section><section><label>Emissions</label><strong>13</strong><h3>Climate Action</h3><p>Track absolute reductions against fixed baselines. Report supplier participation separately.</p></section></div>
<footer>United Nations (n.d.-a, n.d.-b, n.d.-c) and Schneider Electric (2020, 2026a, n.d.-a)<span>10 / 12</span></footer>

---

<header>Discussion and conclusion<span>Schneider Electric · Impact 2030</span></header>

# Which evidence would you fund next?

<div class="split"><aside>Households</aside><section><h3>A 12-month follow-up</h3><p>Trace the same households to see who kept service, what they paid and how often power failed.</p></section></div><div class="split"><aside>Suppliers</aside><section><h3>A matched emissions inventory</h3><p>Compare the same suppliers across two years, with consistent boundaries and a record of production changes.</p></section></div><div class="note" v-click>Our judgement: Schneider demonstrates reach, lower operating emissions and customer efficiency. Follow-up would show how much of that progress lasts.</div>
<footer>Synthesis of the evidence on slides 3–10<span>11 / 12</span></footer>

---

<header>References<span>Schneider Electric · Impact 2030</span></header>

# Sources

<div class="bibliography"><p>Lee, K., Miguel, E., &amp; Wolfram, C. (2020). <a href="https://doi.org/10.1086/705417">Experimental evidence on the economics of rural electrification.</a> <i>Journal of Political Economy, 128</i>(4), 1523–1565.</p><p>Schneider Electric. (n.d.-a). <a href="https://www.se.com/ww/en/about-us/investor-relations/investment/esg/">ESG strategy FAQ.</a></p><p>Schneider Electric. (n.d.-b). <a href="https://www.se.com/ww/en/about-us/sustainability/our-impact/">Our impact.</a></p><p>Schneider Electric. (2020, September 4). <a href="https://perspectives.se.com/case-study/maximizing-cement-production-efficiency-for-cnbm">Energy-intensive industry paves the way to sustainability.</a></p><p>Schneider Electric. (2026a, October 16). <a href="https://www.se.com/ww/en/about-us/newsroom/news/press-releases/schneider-electric-reports-robust-sustainability-progress-for-its-third-quarter-results-6ad1ab2a5d3dbde2c90c14a3/">Schneider Electric reports robust sustainability progress for its third quarter results.</a></p><p>Schneider Electric. (2026b). <a href="https://www.se.com/za/en/about-us/newsroom/news/press-releases/schneider-electric-to-become-the-official-energy-technology-partner-of-mclaren-racing-6978b17cef0e31a06901130d/">Schneider Electric to become the official energy technology partner of McLaren Racing.</a></p><p>United Nations. (n.d.-a). <a href="https://sdgs.un.org/goals/goal13">Goal 13: Climate action.</a></p><p>United Nations. (n.d.-b). <a href="https://sdgs.un.org/goals/goal7">Goal 7: Affordable and clean energy.</a></p><p>United Nations. (n.d.-c). <a href="https://sdgs.un.org/goals/goal9">Goal 9: Industry, innovation and infrastructure.</a></p></div>
<footer>Select a title to open the source.<span>12 / 12</span></footer>
