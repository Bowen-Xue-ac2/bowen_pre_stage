---
theme: default
title: Schneider Electric | Impact 2030
routerMode: hash
colorSchema: light
transition: fade
fonts:
  sans: Arial
  provider: none
---

<div class="cover">
<header>Schneider Electric <span>Impact 2030</span></header>
<div class="arc"></div>
<h1>Energy access<br>and industrial change</h1>
<p>Evidence workbook for a five-speaker presentation</p>
<footer>Visual planning edition <span>November 2026</span></footer>
</div>

---

<header>Mission and position <span>01 / Context</span></header>

# What change does Schneider aim to deliver?

<div class="split"><aside>Mission</aside><section><h3>Official wording</h3><p>Insert the verified mission and its source here.</p></section></div>
<div class="split" v-click><aside>Position</aside><section><h3>The group’s judgement</h3><p>Choose the impact you can defend most strongly. Identify the evidence that could change your judgement.</p></section></div>
<footer>Discussion sequence <span>Aims → Stakeholders → Change pathways → SDGs</span></footer>

---

<header>Impact measures <span>02 / Aims</span></header>

# Three figures describe different kinds of progress

<div class="kpis">
<section><label>Energy access</label><strong>69m</strong><p>People who gained access to sustainable electricity since 2009.</p></section>
<section><label>Own operations</label><strong>83%</strong><p>Reduction in Scope 1 and 2 emissions against 2017.</p></section>
<section><label>Customer energy use</label><strong>211m</strong><p>MWh saved or electrified in the first nine months of 2026.</p></section>
</div>
<footer>Schneider Electric (2026), Q3 sustainability update [1] <span>Reported indicators</span></footer>

---

<header>Stakeholders <span>02 / Aims</span></header>

# Who decides, who delivers and who feels the effects?

<div class="lanes"><section><label>Inside Schneider</label><h3>Board and programme leads</h3><p>Funding decisions and accountability</p></section><section><label>Across delivery partners</label><h3>Suppliers and local operators</h3><p>Implementation and reporting</p></section><section><label>At the point of use</label><h3>Households and industrial customers</h3><p>Reliability, affordability and operating costs</p></section></div>
<footer>Mapping exercise <span>Choose one competing interest to explain.</span></footer>

---

<header>Customer evidence <span>02 / Aims</span></header>

# Where does efficiency create economic value?

<div class="split"><aside>211m MWh</aside><section><h3>Energy saved or electrified</h3><p>The combined figure covers two different changes in customers’ energy use.</p></section></div>
<div class="split" v-click><aside>Case evidence</aside><section><h3>Cost per unit of output</h3><p>Add one customer’s before-and-after measure, period and production baseline. Account for changes in energy prices.</p></section></div>
<footer>Schneider Electric (2026) [1] <span>Economic impact evidence to collect</span></footer>

---

<header>Theory of Change 01 <span>03 / Energy access</span></header>

# Trace an energy-access project from funding to follow-up

<div class="chain"><section><label>Inputs</label><p>Partner funding and staff</p></section><section><label>Processes</label><p>Installation and training</p></section><section><label>Outputs</label><p>Connections delivered</p></section><section><label>Outcomes</label><p>Service still in use</p></section><section><label>Impact</label><p>Affordable, reliable electricity</p></section></div>
<div class="note">Team worksheet · Add one sourced quantity or labelled estimate to each stage, with a date and a unit.</div>
<footer>Future pathway <span>0–12 months / 12–18 months / to 2030</span></footer>

---

<header>Household evidence <span>03 / Energy access</span></header>

# What happens after the first connection?

<div class="feature"><strong>69m</strong><div><label>Cumulative reach</label><p>People who gained access to sustainable electricity since 2009, as reported at Q3 2026.</p></div></div>
<div class="note" v-click>Follow-up measure to design · Of households connected a year ago, what share still receives reliable service at a cost it can afford?</div>
<footer>Schneider Electric (2026) [1] <span>Proposed follow-up requires household data.</span></footer>

---

<header>Theory of Change 02 <span>04 / Supplier emissions</span></header>

# Follow suppliers from initial support to emissions reporting

<div class="chain"><section><label>Inputs</label><p>Digital tools deployed for 1,200+ suppliers</p></section><section><label>Processes</label><p>10 supplier bootcamps</p></section><section><label>Outputs</label><p>135 qualified at Q3 2026</p></section><section><label>Outcomes</label><p>Select a measured emissions change</p></section><section><label>Impact</label><p>Test the contribution to 2030 value-chain reductions</p></section></div>
<div class="note">Complete the pathway with a baseline, interim milestone and 2030 emissions target. Label every projection.</div>
<footer>Schneider Electric (2026) [1] <span>Zero Carbon Pathway</span></footer>

---

<header>Supplier evidence <span>04 / Supplier emissions</span></header>

# Supplier qualifications rose from 15 to 135

<div class="bars"><div><label>H1 2026</label><i style="width:6%"></i><b>15</b></div><div><label>Q3 2026</label><i style="width:54%"></i><b>135</b></div></div>
<div class="note" v-click>Qualification includes measuring emissions and adopting a reduction target. A follow-up comparison needs actual emissions over a consistent period and boundary.</div>
<footer>Schneider Electric (2026) [1] <span>Qualified suppliers, count</span></footer>

---

<header>Sustainable Development Goals <span>05 / Evaluation</span></header>

# Which evidence supports each SDG link?

<div class="kpis goals"><section><label>Household access</label><strong>07</strong><h3>Affordable and Clean Energy</h3><p>Examine affordability and continuity of service.</p></section><section><label>Customer efficiency</label><strong>09</strong><h3>Industry, Innovation and Infrastructure</h3><p>Trace one industrial upgrade to its resource use.</p></section><section><label>Emissions</label><strong>13</strong><h3>Climate Action</h3><p>Separate operational reductions from supplier progress.</p></section></div>
<footer>United Nations, Goals 7, 9 and 13 [2–4] <span>Team evaluation</span></footer>

---

<header>Discussion and conclusion <span>05 / Evaluation</span></header>

# Which outcome would you verify first?

<div class="split"><aside>Households</aside><section><h3>Lasting access to electricity</h3><p>What could a household follow-up establish?</p></section></div>
<div class="split"><aside>Suppliers</aside><section><h3>Lower value-chain emissions</h3><p>What could a comparable emissions inventory establish?</p></section></div>
<footer>Conclusion prompt <span>Return to the group’s opening position using evidence already shown.</span></footer>

---

<header>Source notes <span>Appendix</span></header>

# Sources for the figures and goal descriptions

<div class="refs">
<p>[1] Schneider Electric. (2026, October 16). <a href="https://www.se.com/ww/en/about-us/newsroom/news/press-releases/schneider-electric-reports-robust-sustainability-progress-for-its-third-quarter-results-6ad1ab2a5d3dbde2c90c14a3/">Schneider Electric reports robust sustainability progress for its third quarter results.</a></p>
<p>[2] United Nations. (n.d.). <a href="https://sdgs.un.org/goals/goal7">Goal 7: Affordable and clean energy.</a></p>
<p>[3] United Nations. (n.d.). <a href="https://sdgs.un.org/goals/goal9">Goal 9: Industry, innovation and infrastructure.</a></p>
<p>[4] United Nations. (n.d.). <a href="https://sdgs.un.org/goals/goal13">Goal 13: Climate action.</a></p>
</div>
<footer>Planning edition <span>Add the group’s academic and case sources when completing the analysis.</span></footer>
